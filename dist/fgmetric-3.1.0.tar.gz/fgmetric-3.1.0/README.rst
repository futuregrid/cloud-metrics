=====================
LOG ANALYZER FOR CLOUDS v2.1
=====================

download the code
cd doc
make html
open build/html/index.html

